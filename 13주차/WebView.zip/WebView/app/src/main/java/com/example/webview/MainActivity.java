package com.example.webview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.DownloadListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements DownloadListener {

    WebView web01;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        web01 =(WebView) findViewById(R.id.webView01);

        web01.setWebViewClient(new WebViewClient());

        web01.setDownloadListener(this);

        web01.getSettings().setJavaScriptEnabled(true);
        web01.getSettings().setBuiltInZoomControls(true);
        web01.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);

        web01.clearCache(true);

        web01.clearHistory();

        web01.loadUrl("https://www.seoil.ac.kr/");
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if ((keyCode == KeyEvent.KEYCODE_BACK) && web01.canGoBack()) {
            web01.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
        Toast.makeText(this, "onDownloadStart", Toast.LENGTH_SHORT).show();

        Intent intent01 = new Intent(Intent.ACTION_VIEW);
        intent01.setData(Uri.parse(url));

        startActivity(intent01);
    }
}