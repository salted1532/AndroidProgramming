package com.example.bevent;

import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.GestureDetector;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity
        implements View.OnClickListener,
                    View.OnLongClickListener,
                    View.OnFocusChangeListener,
                    View.OnKeyListener,
                    View.OnTouchListener{

    // 'callback'을 클래스 수준에서 선언
    private OnBackPressedCallback callback;
    private GestureDetector gestureDetector;
    Button btn01, btn02;
    EditText edit01, edit02;
    TextView text01;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn01 = (Button) findViewById(R.id.button01);
        btn01.setOnClickListener(this);
        btn01.setOnLongClickListener(this);

        //btn02 = (Button) findViewById(R.id.button02);
        //btn02.setOnLongClickListener(this);

        edit01 = (EditText) findViewById(R.id.editText01);
        edit01.setOnFocusChangeListener(this);

        edit02 = (EditText) findViewById(R.id.editText02);
        edit02.setOnKeyListener(this);

        text01 = (TextView) findViewById(R.id.textView01);
        text01.setOnTouchListener(this);

        gestureDetector = new GestureDetector(this, new GestureDetector.OnGestureListener() {
            @Override
            public boolean onDown(@NonNull MotionEvent e) {
                return false;
            }

            @Override
            public void onShowPress(@NonNull MotionEvent e) {

            }

            @Override
            public boolean onSingleTapUp(@NonNull MotionEvent e) {
                return false;
            }

            @Override
            public boolean onScroll(@Nullable MotionEvent e1, @NonNull MotionEvent e2, float distanceX, float distanceY) {
                float distX = e1.getX() - e2.getX();
                float distY = e1.getY() - e2.getY();

                float distXAbs = Math.abs(distX);
                float distYAbs = Math.abs(distY);

                if(distXAbs > 50) {
                    if(distX > 0) {
                        text01.setText("Move LEFT");
                    } else  {
                        text01.setText("Move RIGHT");
                    }
                }
//                if(distYAbs > 50) {
//                    if(distY > 0) {
//                        text01.setText("Move UP");
//                    } else  {
//                        text01.setText("Move DOWN");
//                    }
//                }
                return false;
            }

            @Override
            public void onLongPress(@NonNull MotionEvent e) {

            }

            @Override
            public boolean onFling(@Nullable MotionEvent e1, @NonNull MotionEvent e2, float velocityX, float velocityY) {
                return false;
            }
        });
        //back 키 제어
        callback = new OnBackPressedCallback(true) {

            @Override
            public void handleOnBackPressed() {
                Toast.makeText(MainActivity.this, "onClick", Toast.LENGTH_LONG).show();
            }
        };
        getOnBackPressedDispatcher().addCallback(this, callback);
    }
    //depressed 됨 --> onBackPressedCallBack으로 변경
//    public void onBackPressed() {
//
//        super.onBackPressed();
//    }

    @Override
    protected void onUserLeaveHint() {
        //super.onUserLeaveHint();
        // 홈 버튼이 눌렸을 때 처리할 로직
        // 예: 로그 기록, 상태 저장 등
    }

    @Override
    public void onClick(View v) {

        Toast.makeText(this, "onClick", Toast.LENGTH_LONG).show();
        //Toast 객체 양식
        //a = Toast.makeText(this, "출력할 메시지", Toast.LENGTH_LONG);
        //a.show();
    }

    public boolean onScroll(@Nullable MotionEvent e1, @NonNull MotionEvent e2, float distanceX, float distanceY) {
        float distX = e1.getX() - e2.getX();
        float distY = e1.getY() - e2.getY();

        float distXAbs = Math.abs(distX);
        float distYAbs = Math.abs(distY);

        if(distX > 150) {
            if(distX > 0) {
                text01.setText("Move LEFT");
            }
        }

        return false;
    }

    @Override
    public boolean onLongClick(View v) {
        Toast.makeText(this, "onLongClick", Toast.LENGTH_LONG).show();
        return true;
    }

    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        String s = "";
        if(hasFocus) {
            ((EditText) v).setText("");
        } else {
            s = edit01.getText().toString();
            edit01.setText(s + " + focus change");
        }
    }

    @Override
    public boolean onKey(View v, int keyCode, KeyEvent event) {
        if(keyCode == KeyEvent.KEYCODE_BACK) {
            Toast.makeText(this, "KEYCODE_BACK", Toast.LENGTH_LONG).show();
        }
        if(keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            text01.setText("Volume Up");
        }
        if(keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            text01.setText("Volume Down");
        }

        if(keyCode == KeyEvent.KEYCODE_W) {
            text01.setText("W key detected");
        }
        if(keyCode == KeyEvent.KEYCODE_A) {
            text01.setText("A key detected");
        }
        if(keyCode == KeyEvent.KEYCODE_S) {
            text01.setText("S key detected");
        }
        if(keyCode == KeyEvent.KEYCODE_D) {
            text01.setText("D key detected");
        }

        return false;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
//        if(event.getAction() == MotionEvent.ACTION_DOWN) {
//            text01.setText("ACTION_DOWN");
//            return true;
//        }
//        if(event.getAction() == MotionEvent.ACTION_MOVE) {
//            float x = event.getX();  // X 좌표
//            float y = event.getY();  // Y 좌표
//            text01.setText("X: " + x + ", Y: " + y);  // 좌표값을 문자열로 설정
//            return true;
//        }
//        if(event.getAction() == MotionEvent.ACTION_UP) {
//            text01.setText("ACTION_UP");
//            return true;
//        }
        gestureDetector.onTouchEvent(event);
        return true;
    }



}