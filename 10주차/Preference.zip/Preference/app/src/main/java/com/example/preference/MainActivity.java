package com.example.preference;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText edit01, edit02;
    Button btn01, btn02;
    Button btn03;

    EditText editMulti01;

    SharedPreferences spref;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edit01 = (EditText) findViewById(R.id.editTextText01);
        edit02 = (EditText) findViewById(R.id.editTextText02);

        editMulti01 = (EditText) findViewById(R.id.editTextTextMultiLine01);

        btn01 = (Button) findViewById(R.id.button01);
        btn02 = (Button) findViewById(R.id.button02);
        btn03 = (Button) findViewById(R.id.button03);

        btn01.setOnClickListener(this);
        btn02.setOnClickListener(this);
        btn03.setOnClickListener(this);

        spref = getSharedPreferences("gpref", MODE_PRIVATE);
        editor = spref.edit();

        String temp1 = spref.getString("editText01", "1");
        String temp2 = spref.getString("editText02", "2");

        edit01.setText(temp1);
        edit02.setText(temp2);

        editMulti01.setText("ID: " + temp1 + "\n"+ "PW: " + temp2);
    }

    @Override
    public void onClick(View v) {
        String txt01, txt02;
        txt01 = edit01.getText().toString();
        txt02 = edit02.getText().toString();

        if(v.getId() == R.id.button01) {
            editor.putString("editText01", txt01);
            editor.putString("editText02", txt02);
            editor.apply();
            editMulti01.setText("ID: " + txt01 + "\n"+ "PW: " + txt02);
        }
        if(v.getId() == R.id.button02) {
            finish();
        }
        //리셋 버튼 코드
        if(v.getId() == R.id.button03) {
            editor.putString("editText01", null);
            editor.putString("editText02", null);
            editor.apply();
            //리셋 시 기본값이였던 1, 2로 출력
            editMulti01.setText("ID: " + "1" + "\n"+ "PW: " + "2");
        }
    }
}