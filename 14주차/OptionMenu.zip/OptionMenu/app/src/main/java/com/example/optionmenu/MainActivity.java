package com.example.optionmenu;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Toolbar toolbar;

    int tbColor;

    Button btn01;

    int flag = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = (Toolbar) findViewById(R.id.toolbar01);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.home_24px);

        tbColor = ContextCompat.getColor(this, R.color.tb_color);

        toolbar.setBackgroundColor(tbColor);
        getWindow().setStatusBarColor(tbColor);

        btn01 = (Button) findViewById(R.id.button01);
        btn01.setOnClickListener(this);

    }

    //메뉴 생성 (Activity 작동시 자동으로 실행)
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if(flag  == 0) {
            getMenuInflater().inflate(R.menu.main_option, menu);
        }
        else {
            getMenuInflater().inflate(R.menu.main_option2, menu);
            menu.add(0,1,0,"add menu")
                    .setIcon(R.drawable.planet_24px)
                    .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
            menu.add(0,2,0,"add menu")
                    .setIcon(R.drawable.planet_24px)
                    .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
            menu.add(0,3,0,"add menu")
                    .setIcon(R.drawable.planet_24px)
                    .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        }
        return super.onCreateOptionsMenu(menu);
    }
    //선택된 메뉴 속 아이템 처리
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == android.R.id.home) {
            Toast.makeText(this, "Home", Toast.LENGTH_LONG).show();
        }
        if(id == R.id.item1) {
            Toast.makeText(this, "Menu 1", Toast.LENGTH_LONG).show();
        }
        if(id == R.id.item2) {
            Toast.makeText(this, "Menu 2", Toast.LENGTH_LONG).show();
        }
        if(id == R.id.item3) {
            Toast.makeText(this, "Sub Menu", Toast.LENGTH_LONG).show();
        }
        if(id == R.id.item4) {
            Toast.makeText(this, "Sub Menu 1", Toast.LENGTH_LONG).show();
        }
        if(id == R.id.item5) {
            Toast.makeText(this, "Sub Menu 2 - Close", Toast.LENGTH_LONG).show();
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        if(flag == 0) {
            flag = 1;
            invalidateOptionsMenu();//onCreateOptionsMenu() 작동 시킴
        }
        else {
            flag = 0;
            invalidateOptionsMenu();//onCreateOptionsMenu() 작동 시킴
        }

    }
}