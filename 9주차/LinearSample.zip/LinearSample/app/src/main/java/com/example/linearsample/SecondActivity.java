package com.example.linearsample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SecondActivity extends AppCompatActivity implements View.OnClickListener{

    EditText editText01;
    Button btn01;
    String receive, result;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        receive = getIntent().getStringExtra("SendData");
        if(receive != null) {
            editText01 = (EditText)findViewById(R.id.result_editTextText);
            editText01.setText(receive);
        }

        btn01 = (Button)findViewById(R.id.button03);
        btn01.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.button03) {
            result = editText01.getText().toString();
            if (result.length() != 0) {
                Intent intent01 = new Intent();
                intent01.putExtra("ResultData", result);
                setResult(RESULT_OK, intent01);
            } else {
                setResult(RESULT_CANCELED);
            }
            finish();
        }
    }
}