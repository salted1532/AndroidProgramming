package com.example.inputstream;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private static final String LOCAL_FILE = "memo_data.text";

    EditText edit01;
    Button btn01, btn02;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edit01 = (EditText) findViewById(R.id.editTextText01);

        btn01 =(Button) findViewById(R.id.button01);
        btn01.setOnClickListener(this);

        btn02 =(Button) findViewById(R.id.button02);
        btn02.setOnClickListener(this);

        InputStream in;
        BufferedReader reader;

        try {
            in = openFileInput(LOCAL_FILE);
        } catch (FileNotFoundException e) {
            in = getResources().openRawResource(R.raw.raw_data);
        }

        try {
            reader = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            String str;
            while ((str = reader.readLine()) != null) {
                edit01.append(str);
                edit01.append("\n");
            }
        } catch (IOException e) {
            Log.e("Local File", e.getMessage());
        }
    }
    //close 버튼을 누를 시 pause단계에서 onPause()작동하여 로컬파일이 저장됨
    protected void onPause() {
        super.onPause();

        String str = edit01.getText().toString();
        if(str.length() == 0) {
            deleteFile(LOCAL_FILE);
            return;
        }
        try {
            OutputStream out = openFileOutput(LOCAL_FILE, MODE_PRIVATE);
            PrintWriter writer = new PrintWriter(new OutputStreamWriter(out, "UTF-8"));
            writer.append(str);
            writer.close();
        } catch (IOException e) {
            Log.e("Local File", e.getMessage());
        }
    }
    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.button01) {
            finish();
        }
        //파일 삭제 버튼 코드
        if(v.getId() == R.id.button02) {
            deleteFile(LOCAL_FILE);
            edit01.setText("");
        }

    }
}