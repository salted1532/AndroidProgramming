package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btn01, btn02, btn03;

    EditText editText01;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText01 = (EditText)findViewById(R.id.editTextText01);
        btn01 = (Button)findViewById(R.id.button01);
        btn02 = (Button)findViewById(R.id.btn);
        btn03 = (Button)findViewById(R.id.button03);

        btn01.setOnClickListener(this);
        btn02.setOnClickListener(this);
        btn03.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.button01) {
            Intent intent01 = new Intent( MainActivity.this , SecondActivity.class);
            intent01.putExtra("key01", editText01.getText().toString()); //intent.putExtra(구분자, 실제 데이터);
            startActivity(intent01);
        }
        if(view.getId() == R.id.btn) {
            finish();
        }
        if(view.getId() == R.id.button03) {
            editText01.setText("");
        }
    }
}